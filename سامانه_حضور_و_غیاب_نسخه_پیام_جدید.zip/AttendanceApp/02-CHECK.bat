@echo off
setlocal
cd /d "%~dp0"
echo === Attendance app settings ===
findstr /B "SMS_MODE=" .env
findstr /B "SMS_IR_LINE=" .env
findstr /B "PORT=" .env
echo API key is intentionally not displayed.
echo.
pause
endlocal
