const express = require('express');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

const API_BASE = 'https://api.sms.ir/v1';
let runtimeApiKey = process.env.SMS_IR_API_KEY || '';
let runtimeLine = process.env.SMS_IR_LINE || '30002108038239';

function cleanMobile(value) {
  let s = String(value || '').replace(/\s|-/g, '');
  if (s.startsWith('+98')) s = '0' + s.slice(3);
  if (s.startsWith('98') && s.length === 12) s = '0' + s.slice(2);
  return s;
}

app.get('/api/status', (req, res) => {
  res.json({
    configured: Boolean(runtimeApiKey && runtimeLine),
    lineNumber: runtimeLine,
    mode: process.env.SMS_MODE === 'demo' ? 'demo' : 'real'
  });
});


app.post('/api/config', (req, res) => {
  const apiKey = String(req.body?.apiKey || '').trim();
  const lineNumber = String(req.body?.lineNumber || runtimeLine || '').trim();
  if (!apiKey) return res.status(400).json({ error: 'کلید API وارد نشده است.' });
  if (!lineNumber) return res.status(400).json({ error: 'شماره خط وارد نشده است.' });
  runtimeApiKey = apiKey;
  runtimeLine = lineNumber;
  res.json({ ok: true, lineNumber: runtimeLine, configured: true });
});

app.post('/api/test-config', async (req, res) => {
  if (!runtimeApiKey || !runtimeLine) return res.status(400).json({ error: 'ابتدا کلید API و شماره خط را تنظیم کنید.' });
  res.json({ ok: true, message: 'تنظیمات در حافظه سامانه ثبت شد. برای ارسال واقعی، یک پیام آزمایشی از صفحه اصلی ارسال کنید.' });
});

app.post('/api/send', async (req, res) => {
  const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
  if (!messages.length) return res.status(400).json({ error: 'پیامی برای ارسال وجود ندارد.' });

  // Demo mode: no SMS is sent.
  if (process.env.SMS_MODE === 'demo') {
    return res.json({
      mode: 'demo',
      results: messages.map(m => ({
        name: m.name,
        mobile: m.mobile,
        ok: true,
        message: 'حالت آزمایشی: پیام ارسال نشد.'
      }))
    });
  }

  const apiKey = runtimeApiKey;
  const lineNumber = runtimeLine;
  if (!apiKey || !lineNumber) {
    return res.status(500).json({ error: 'کلید API یا شماره خط SMS.ir در تنظیمات سرور وارد نشده است.' });
  }

  const valid = messages.filter(m => cleanMobile(m.mobile) && m.text);
  const invalid = messages.filter(m => !cleanMobile(m.mobile) || !m.text);
  if (!valid.length) {
    return res.status(400).json({ error: 'شماره موبایل معتبر یا متن پیام پیدا نشد.' });
  }

  try {
    const response = await fetch(`${API_BASE}/send/likeToLike`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-API-KEY': apiKey
      },
      body: JSON.stringify({
        lineNumber: Number(lineNumber),
        messageTexts: valid.map(m => String(m.text)),
        mobiles: valid.map(m => cleanMobile(m.mobile)),
        sendDateTime: null
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.status === 0) {
      return res.status(502).json({
        error: data.message || 'SMS.ir ارسال را قبول نکرد.',
        raw: data
      });
    }

    const ids = data.data?.messageIds || [];
    const results = valid.map((m, i) => ({
      name: m.name,
      mobile: m.mobile,
      ok: true,
      message: 'پیام با موفقیت به سرویس SMS.ir ارسال شد.',
      messageId: ids[i] || null
    }));

    for (const m of invalid) {
      results.push({ name: m.name, mobile: m.mobile, ok: false, message: 'شماره موبایل یا متن پیام ناقص است.' });
    }

    res.json({ mode: 'real', results, packId: data.data?.packId || null, cost: data.data?.cost || null });
  } catch (error) {
    res.status(502).json({ error: 'ارتباط با SMS.ir برقرار نشد.', detail: error.message });
  }
});

app.listen(process.env.PORT || 3000, () => {
  console.log(`Attendance app running on http://localhost:${process.env.PORT || 3000}`);
});
