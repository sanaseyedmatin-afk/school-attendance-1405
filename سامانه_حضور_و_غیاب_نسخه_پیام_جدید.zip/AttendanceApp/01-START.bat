@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js 18 or newer, then run this file again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing required packages. Please wait...
  call npm install
  if errorlevel 1 (
    echo npm install failed.
    echo Check your internet connection and try again.
    pause
    exit /b 1
  )
)
if not exist .env (
  copy /Y .env.example .env >nul
)
for /f "tokens=2 delims==" %%A in ('findstr /B "PORT=" .env') do set PORT=%%A
if "%PORT%"=="" set PORT=3000
echo Starting attendance server on port %PORT%...
start "Attendance Server" cmd /k "cd /d "%~dp0" && npm start"
timeout /t 2 /nobreak >nul
start "" "http://localhost:%PORT%"
endlocal
